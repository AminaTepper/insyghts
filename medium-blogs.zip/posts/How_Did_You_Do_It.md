# 🎓 How Did You Do It?  
**Originally published on [Medium](https://medium.com/@amina.shahzad/how-did-you-do-it)**  
**Date:** May 13, 2025  

---

A reflection on balancing graduate studies, full-time work, and family — offering practical insights on resilience, structure, and lifelong learning.
